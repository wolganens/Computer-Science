#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node.h"


Node * syntax_tree;

void addNodoLista (Node *node, listaNodos **raiz){
	if (*raiz == NULL) { //Verifica se a lista está vazia
		if ((*raiz = malloc(sizeof(listaNodos))) == NULL){//inicializa a lista alocando memória para a raíz
			perror("malloc() error:");
			exit(-1);
		}
		
		(*raiz)->node = node; //Define o novo nodo inserido como raíz da lista
		(*raiz)->prox = NULL; 
	}
	else{ // se á árvore não estiver vazia adiciona o nodo como próximo da lista
		listaNodos **anterior = raiz;
		listaNodos **proximo = &((*raiz)->prox);
		
		while (*proximo != NULL){
			anterior = proximo;
			proximo = &((*proximo)->prox);
		}
		
		if ((*proximo = malloc(sizeof(listaNodos))) == NULL){
			perror("malloc() error:");
			exit(-1);
		}
		
		(*proximo)->prox = NULL;
		(*proximo)->node = node;
	}
}

Node* create_node(int nl, Node_type t, char* lexeme,  Node* children, ...) {
    
	va_list ap;
	va_start(ap, children); // Informações a respeito dos parâmetros variaveis.
			
	Node *novo;	

	if ((novo = (Node *) malloc(sizeof(Node))) == NULL){ // alocar espaço na memória para o novo nodo	
		perror("");
		exit(-1);
	}	
	/*Atributos do TAD Node*/
	novo->line_num = nl;
	novo->lexeme = lexeme;
	novo->type = t;
	novo->children = NULL;

	
	Node* child;
	
	for (child = children; child != NULL; child = va_arg(ap, Node*)){//Avança na lista de parametros variaveis	
		addNodoLista(child, &(novo->children)); // para cada parametro variavel insere o nodo na lista
	}
	
	va_end(ap);
	
	return novo;
}
int nb_of_children(Node* n){ // Retorna o número de filhos de um nodo
	
	if (n == NULL){
		exit(-1);
	}
	else{
		Nodelist *anterior = n->children;
		int i = 0;
		
		
		for (i = 0; anterior != NULL; i++)
		{	
			anterior = anterior->next;		
		}	
		return i;
	}
	
}
Node* child(Node* n, int i) { // retorna o filho i de um nodo
	
	if (n == NULL){ //Se o nodo for null, encerra com erro
		exit(-1);
	}

	if (i <= 0 || i > nb_of_children(n)){ // impede de acesso fora do espaço alocado
		exit(-1);
	}

	Nodelist *anterior = n->children;
	
	int j;
	
	for (j = 0; j != i-1; j++){
		anterior = anterior->next;
	}

	return anterior->node;
}
int deep_free_node(Node* n){//libera o espaço de um nodo e de seus filhos
	/*Se o nodo n não tiver filhos, libera o espaço do mesmo e retorna*/
	if (nb_of_children(n) == 0)	{
		free(n);
		return 1;
	}
	
	Nodelist *anterior = n->children;
	Nodelist *proximo = anterior->next;
	
	while(anterior != NULL)	{
		deep_free_node(anterior->node);
		anterior = proximo;
		
		if (proximo != NULL){
			proximo = proximo->next;		
		}
	}
	
	free(n);
	
	return 1;
}