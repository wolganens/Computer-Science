#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "node.h"


Node * syntax_tree;

Node* create_node(int nl, Node_type t,char* lexeme, int n_child, Node** children) {
	
    Node *new_node = malloc(sizeof(Node));
	
    if( new_node == NULL){
		printf("Erro ao alocar memória para o nó.\n");
		exit(-1);
	}
	else{
		new_node->line_num = nl;
		new_node->lexeme = malloc(sizeof(char)*(strlen(lexeme) + 1));
		strncpy(new_node->lexeme, lexeme, strlen(lexeme));		        
        new_node->lexeme[strlen(lexeme)] = '\0';
        new_node->type = t;
        new_node->n_child = n_child;
        new_node->children = children;
	}
	return new_node;
}
int nb_of_children(Node* n){
	return n->n_child;
}
int is_leaf(Node* n){
	if (n->children == NULL){
		return 1;
	}
	else{
		return 0;
	}
}
Node* child(Node* n, int i){
	if( n == NULL){
		exit(-1);
	}
	if(n->children == NULL || i >= n->n_child || i < 0 ){
		exit(-1);
	}
	return n->children[i];
}
int deep_free_node(Node* n) {
   int ret=0; /*retorno da função*/
   int i; /*auxiliar para laço*/
   /*verifica se há algo para liberar*/
   if(n == NULL)
       return 0;
   /*libera todos os filhos*/
   if(n->n_child > 0)
       for(i=0; i< n->n_child; i++)
           ret +=deep_free_node(n->children[i]);
   /*apaga esse próprio nó*/
    free(n);
    return ret;
}
int height(Node *n) {
    int max=0; /*maior altura entre as subárvores filhas*/
    int alt; /*auxiliar para guardar altura da subárvore filha*/
    int i; /*auxiliar para laço*/
   /*a altura de uma árvore vazia é 0*/
    if(n == NULL)
        return 0;
    /*calcula a altura abaixo desse nó*/
    for(i=0; i < n->n_child; i++)
    {
        /*pega a altura dessa subárvore*/
        alt = height(n->children[i]);
        /*vê se é maior que a máxima*/
        if(max < alt) 
            max = alt;
    }
    /*retorna a altura total dessa árvore: 1 + a altura da maior subárvore*/
    return 1 + max;
}