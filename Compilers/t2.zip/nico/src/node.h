/** @file node.h
 *  @version 1.2
 */

#ifndef _NODE_H_
#define _NODE_H_

#ifdef __GNUC__
    /* If using gcc, warn about missing sentinel NULLs */
    #define NULL_TERMINATED __attribute__((sentinel))
#else
    #define NULL_TERMINATED
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>


typedef int Node_type;

/* Serie de constantes que servirao para definir tipos de nos (na arvore). 
 * Essa serie pode ser completada ou alterada a vontade.
 */
#define code_node               298
#define declaracoes_node        299
#define declaracao_node         300
#define tipo_node               301
#define tipounico_node          302
#define int_node                501
#define listadeclaracao_node    502
#define double_node             503
#define real_node               504
#define char_node               505
#define tipolista_node          506
#define listadupla_node         507
#define int_lit_node            508
#define double_lit_node         509
#define char_lit_node           510
#define real_lit_node           511
#define colon_node              512
#define acoes_node              513
#define lvalue_node             514
#define semicolon_node          515
#define comando_node            516
#define left_bracket_node       517
#define right_bracket_node      518
#define add_op_node             519
#define sub_op_node             520
#define mul_op_node             521
#define div_op_node             522
#define float_lit_node          523
#define chama_proc_node         524
#define if_node                 525
#define expbool_node            526
#define then_node               527
#define fiminstcontrole         528
#define while_node              529
#define left_s_bracket_node     530
#define right_s_bracket_node    531
#define end_node                532
#define fiminstcontrole_node    533
#define true_node               534
#define false_node              535
#define and_node                536
#define or_node                 537
#define not_node                538
#define greater_than_node       539
#define less_than_node          540
#define less_equal_node         541
#define greater_equal_node      542
#define equal_node              543
#define not_equal_node          544
#define right_par_node          545
#define left_par_node           546
#define comma_node              547
#define expr_node               548
#define swap_node               549
#define bloco_node              550
#define idf_node                551
#define listaexpr_node          552

 
 
/*#define idf_node                519
#define idf_node                520*/
/* A completar */


/** Estrutura de dados parcial para o no da arvore. */
typedef struct _node {
    int line_num;   /**< numero de linha. */
    char* lexeme;   /**< o lexema retornado pelo analizador lexical. */
    Node_type type; /**< Um dos valores definidos acima pelos # defines. */
    void* attribute;/**< Qualquer coisa por enquanto. */
    int n_child;
    struct _node **children;
    /* ...
    * Completar essa estrutura de dados com o necessário
    * para a implementacao dos metodos especificados.
    * ...
    */
} Node;

extern Node * syntax_tree;


/**
 * Node constructor.
 *
 * @param nl: line number where this token was found in the source code.
 * @param t: node type (one of the values #define'd above). Must abort
 *             the program if the type is not correct.
 * @param lexeme: whatever string you want associated to this node.
 * @param children...: NULL-terminated list of pointers to children Node*'s.
 *     See the extra file 'exemplo_func_var_arg.c' for an example.
 *     Callers are expected to pass *only Node pointers* as arguments.
 *     To create a leaf, use just NULL.
 * @return a pointer to a new Node.
 */
NULL_TERMINATED

Node* create_node(int nl, Node_type t,char* lexeme, int n_child, Node** children);

/** Accessor to the number of children of a Node.
 *  Must abort the program if 'n' is NULL.
 */
int nb_of_children(Node* n);

/** Tests if a Node is a leaf.
 *  Must abort the program if 'n' is NULL.
 *  @return 1 if n is a leaf, 0 else.
 */
int is_leaf(Node* n);

/** accessor to the i'th child of a Node.
 * @param n : the node to be consulted. Must abort the program if 'n' is NULL.
 * @param i : the number of the child that one wants. Given a node degree d,
 *       valid values for i are: 0 <= i < d.
 *       Must abort the program if i is not correct.
 * @return a pointer to a Node.
 */
Node* child(Node* n, int i) ;

/** Destructor of a Node. Deallocates
 * (recursively) all of the tree rooted at 'n'.
 */
int deep_free_node(Node* n) ;

/** Returns the height of the tree rooted by 'n'.
 *  The height of a leaf is 1. 
 */
int height(Node *n) ;

/** Prints into a file the lexemes contained in the node rooted by 'n'.
 *  Lexemes must be printed in a depth-first order.
 *  @param outfile : the file to which the lexemes are printed.
 *  @param n : the root node of the tree. Must abort the program if 'n' is NULL.
 *
 */
void uncompile(FILE* outfile, Node *n) ;


#endif
